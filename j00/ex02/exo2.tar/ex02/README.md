# piscine41
les perm de test6 ne sont pas modifiees

car pas modifiable...

test06 est un link, et pour link test6-> test0 qui est une dir j'ai du creer
un soft link / symbolic link, qui ne peut pas avoir des perm modifiees sur linux

on peut le faire sur macos ce que les ordi de la piscine utilisent donc je
considere cet exercice termine
